import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/pedido.dart';
import '../models/tienda.dart';
import 'supabase_service.dart';

class PedidosService {
  static SupabaseClient get _db => SupabaseService.client;

  static Future<Pedido> obtenerPedidoPorId(String pedidoId) async {
    final data = await _db.from('pedidos').select().eq('id', pedidoId).single();
    return Pedido.fromMap(data);
  }

  static Stream<Pedido?> streamPedido(String pedidoId) {
    return _db
        .from('pedidos')
        .stream(primaryKey: ['id'])
        .eq('id', pedidoId)
        .map((rows) => rows.isEmpty ? null : Pedido.fromMap(rows.first));
  }

  /// Solo pedidos activos (eliminado_en IS NULL).
  static Future<List<Pedido>> listarPedidos() async {
    final data = await _db
        .from('pedidos')
        .select()
        .filter('eliminado_en', 'is', null)
        .order('creado_en', ascending: false);
    return (data as List).map((e) => Pedido.fromMap(e as Map<String, dynamic>)).toList();
  }

  /// Stream en tiempo real de pedidos activos.
  /// Filtramos eliminado_en IS NULL en el cliente porque .stream()
  /// no soporta filtros IS NULL directamente.
  static Stream<List<Pedido>> streamPedidos() {
    return _db
        .from('pedidos')
        .stream(primaryKey: ['id'])
        .order('creado_en', ascending: false)
        .map((rows) => rows
            .map((e) => Pedido.fromMap(e))
            .where((p) => !p.estaEliminado)
            .toList());
  }

  /// Stream en tiempo real de pedidos eliminados (para el panel de restaurar).
  static Stream<List<Pedido>> streamPedidosEliminados() {
    return _db
        .from('pedidos')
        .stream(primaryKey: ['id'])
        .order('eliminado_en', ascending: false)
        .map((rows) => rows
            .map((e) => Pedido.fromMap(e))
            .where((p) => p.estaEliminado)
            .toList());
  }

  static Future<void> actualizarEstadoPago(String pedidoId, String nuevoEstado) async {
    final result = await _db
        .from('pedidos')
        .update({'estado_pago': nuevoEstado})
        .eq('id', pedidoId)
        .select('id');
    if ((result as List).isEmpty) {
      throw Exception('No se pudo actualizar el estado (sin permiso o pedido no encontrado)');
    }
  }

  static Future<void> actualizarEstadoEnvio(String pedidoId, String nuevoEstado) async {
    final result = await _db
        .from('pedidos')
        .update({'estado_envio': nuevoEstado})
        .eq('id', pedidoId)
        .select('id');
    if ((result as List).isEmpty) {
      throw Exception('No se pudo actualizar el estado (sin permiso o pedido no encontrado)');
    }
  }

  /// Guarda la nota interna.
  /// FIX: ahora usa .select() para detectar si la RLS bloqueó el UPDATE
  /// en silencio (el problema que causaba que el SnackBar dijera "guardado"
  /// pero la nota nunca llegara a la base de datos).
  static Future<void> guardarNotaInterna(String pedidoId, String nota) async {
    final result = await _db
        .from('pedidos')
        .update({'notas_internas': nota.isEmpty ? null : nota})
        .eq('id', pedidoId)
        .select('id, notas_internas');
    if ((result as List).isEmpty) {
      throw Exception(
        'No se pudo guardar la nota. '
        'Verifica que tu sesión sea válida (cierra sesión y vuelve a entrar).',
      );
    }
  }

  /// Soft delete: marca eliminado_en con el timestamp actual.
  /// El pedido NO se borra de la base de datos y se puede restaurar.
  static Future<void> eliminarPedido(String pedidoId) async {
    final result = await _db
        .from('pedidos')
        .update({'eliminado_en': DateTime.now().toUtc().toIso8601String()})
        .eq('id', pedidoId)
        .select('id');
    if ((result as List).isEmpty) {
      throw Exception('No se pudo eliminar el pedido (sin permiso o pedido no encontrado)');
    }
  }

  /// Restaura un pedido eliminado: limpia eliminado_en.
  static Future<void> restaurarPedido(String pedidoId) async {
    final result = await _db
        .from('pedidos')
        .update({'eliminado_en': null})
        .eq('id', pedidoId)
        .select('id');
    if ((result as List).isEmpty) {
      throw Exception('No se pudo restaurar el pedido');
    }
  }

  static Future<void> guardarGuiaShalom(
    String pedidoId, {
    required String numeroOrden,
    required String codigoOrden,
  }) async {
    await _db.from('pedidos').update({
      'shalom_numero_orden': numeroOrden.trim(),
      'shalom_codigo_orden': codigoOrden.trim().toUpperCase(),
      'shalom_tracking_activo': true,
      'shalom_ultimo_estado': null,
      'shalom_ultima_verificacion': null,
    }).eq('id', pedidoId);
  }

  static Future<void> quitarGuiaShalom(String pedidoId) async {
    await _db.from('pedidos').update({
      'shalom_numero_orden': null,
      'shalom_codigo_orden': null,
      'shalom_tracking_activo': false,
      'shalom_ultimo_estado': null,
      'shalom_ultima_verificacion': null,
      'shalom_origen': null,
      'shalom_destino': null,
    }).eq('id', pedidoId);
  }

  static Future<void> verificarShalomAhora(String pedidoId) async {
    final response = await _db.functions.invoke(
      'verificar-shalom',
      body: {'pedido_id': pedidoId},
    );
    // Si la Edge Function devuelve un error HTTP, functions.invoke lanza
    // FunctionException. Si devuelve ok:false en el body, lo lanzamos manualmente
    // para que la UI lo muestre como error en vez de quedarse en "Verificando...".
    final data = response.data;
    if (data is Map && data['ok'] == false) {
      final msg = data['error'] ?? 'Error desconocido en la verificación';
      throw Exception(msg.toString());
    }
  }

  static Future<ResumenDashboard> obtenerResumen() async {
    final data = await _db.from('resumen_dashboard').select().maybeSingle();
    return ResumenDashboard.fromMap(data);
  }

  static Future<VentasPeriodo> obtenerResumenVentas({
    required DateTime desde,
    required DateTime hasta,
  }) async {
    final data = await _db.rpc('resumen_ventas_periodo', params: {
      'p_desde': desde.toIso8601String(),
      'p_hasta': hasta.toIso8601String(),
    });
    final fila = (data as List).isNotEmpty ? data.first as Map<String, dynamic> : null;
    return VentasPeriodo.fromMap(fila);
  }
}
